from mpl_plotter.three_d import line


def i():
    line(grid=True, grid_lines='-.', x_tick_number=5, legend=True)


i()

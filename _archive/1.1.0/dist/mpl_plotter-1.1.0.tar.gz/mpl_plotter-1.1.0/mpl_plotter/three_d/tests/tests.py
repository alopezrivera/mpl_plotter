from mpl_plotter.three_d.line import line


def test():
    line(grid=True, grid_lines='-.', x_tick_number=5, legend=True)
